import { motion } from "framer-motion";

export default function MusicPlayer() {
  return (
    <section className="py-16 bg-white/10 backdrop-blur-md">
      <div className="container mx-auto px-4 text-center">
        <motion.h2 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-3xl sm:text-4xl font-bold text-white mb-8 comic-font"
        >
          🎵 Birthday Soundtrack 🎵
        </motion.h2>
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="bg-white/20 rounded-xl p-6 max-w-md mx-auto"
        >
          <p className="text-lg sm:text-xl font-bold cream-text mb-4 comic-font">
            Now Playing: "Kaun Tujhe" by Palak Muchhal
          </p>
          
          <div className="bg-black/50 rounded-lg p-4">
            <iframe 
              src="https://open.spotify.com/embed/track/4bHsxqR3GMrXTxEPLuK5ow?utm_source=generator&theme=0" 
              width="100%" 
              height="152" 
              frameBorder="0" 
              allowFullScreen
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" 
              loading="lazy" 
              className="rounded-lg"
            />
          </div>
          
          <p className="text-sm cream-text mt-4 comic-font">
            🎧 Click play to enjoy the beautiful melody! 🎧
          </p>
        </motion.div>
      </div>
    </section>
  );
}
