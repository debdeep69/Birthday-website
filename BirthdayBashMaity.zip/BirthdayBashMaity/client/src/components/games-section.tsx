import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface GameScores {
  balloon: number;
  memory: number;
  quiz: number;
  cake: number;
  gift: number;
  dance: number;
  wish: number;
}

export default function GamesSection() {
  const [gameScores, setGameScores] = useState<GameScores>({
    balloon: 0,
    memory: 0,
    quiz: 0,
    cake: 0,
    gift: 0,
    dance: 0,
    wish: 0
  });
  
  const [isGameModalOpen, setIsGameModalOpen] = useState(false);
  const [currentGame, setCurrentGame] = useState<number | null>(null);

  const games = [
    {
      id: 1,
      emoji: '🎈',
      title: 'Balloon Pop',
      description: 'Pop balloons for points!',
      bgColor: 'from-pink-400 to-pink-600',
      content: '🎈 Click the balloons to pop them! 🎈<br><br>*Pop* *Pop* *Pop*<br><br>🎉 You popped 5 balloons! 🎉',
      scoreKey: 'balloon' as keyof GameScores,
      scoreText: 'Score: '
    },
    {
      id: 2,
      emoji: '🧠',
      title: 'Memory Match',
      description: 'Match the birthday items!',
      bgColor: 'from-green-500 to-green-700',
      content: '🧠 Match the birthday items! 🧠<br><br>🎂🎁🎈🎊<br><br>🎉 Perfect match! All pairs found! 🎉',
      scoreKey: 'memory' as keyof GameScores,
      scoreText: 'Matches: '
    },
    {
      id: 3,
      emoji: '❓',
      title: 'Birthday Quiz',
      description: 'How well do you know birthdays?',
      bgColor: 'from-purple-500 to-purple-700',
      content: '❓ Birthday Quiz Time! ❓<br><br>Q: What do you blow out on a birthday cake?<br>A: Candles! 🕯️<br><br>🎉 You got all questions right! 🎉',
      scoreKey: 'quiz' as keyof GameScores,
      scoreText: 'Questions: ',
      maxScore: 5
    },
    {
      id: 4,
      emoji: '🎂',
      title: 'Cake Decorator',
      description: 'Design your dream cake!',
      bgColor: 'from-orange-400 to-red-500',
      content: '🎂 Decorate your dream cake! 🎂<br><br>*Adding sprinkles* ✨<br>*Adding flowers* 🌸<br><br>🎉 Beautiful cake created! 🎉',
      scoreKey: 'cake' as keyof GameScores,
      scoreText: 'Decorations: '
    },
    {
      id: 5,
      emoji: '🎁',
      title: 'Gift Unwrapper',
      description: 'Unwrap surprise gifts!',
      bgColor: 'from-yellow-400 to-orange-500',
      content: '🎁 Unwrap the surprise gifts! 🎁<br><br>*Unwrapping* 📦<br>You found: A beautiful necklace! 💎<br><br>🎉 All gifts unwrapped! 🎉',
      scoreKey: 'gift' as keyof GameScores,
      scoreText: 'Gifts: '
    },
    {
      id: 6,
      emoji: '💃',
      title: 'Dance Party',
      description: 'Follow the dance moves!',
      bgColor: 'from-blue-400 to-indigo-600',
      content: '💃 Follow the dance moves! 💃<br><br>👆 Hands up! 👇 Hands down!<br>🔄 Spin around! 💫<br><br>🎉 Perfect dancing! 🎉',
      scoreKey: 'dance' as keyof GameScores,
      scoreText: 'Moves: '
    },
    {
      id: 7,
      emoji: '⭐',
      title: 'Wish Maker',
      description: 'Make birthday wishes come true!',
      bgColor: 'from-pink-400 to-purple-600',
      content: '⭐ Make a birthday wish! ⭐<br><br>*Close your eyes and wish* ✨<br>*Shooting star appears* 🌟<br><br>🎉 Your wish is granted! 🎉',
      scoreKey: 'wish' as keyof GameScores,
      scoreText: 'Wishes: '
    }
  ];

  const playGame = (gameId: number) => {
    setCurrentGame(gameId);
    setIsGameModalOpen(true);
    
    // Update score
    const game = games.find(g => g.id === gameId);
    if (game) {
      setGameScores(prev => ({
        ...prev,
        [game.scoreKey]: prev[game.scoreKey] + 1
      }));
    }
  };

  const closeGame = () => {
    setIsGameModalOpen(false);
    setCurrentGame(null);
  };

  const getScoreDisplay = (game: typeof games[0]) => {
    const score = gameScores[game.scoreKey];
    if (game.maxScore) {
      return `${game.scoreText}${score}/${game.maxScore}`;
    }
    return `${game.scoreText}${score}`;
  };

  return (
    <section className="py-16 bg-white/10 backdrop-blur-md">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-3xl sm:text-4xl font-bold text-center text-white mb-12 comic-font"
        >
          🎮 Birthday Fun Games! 🎮
        </motion.h2>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {games.map((game, index) => (
            <motion.div
              key={game.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`game-card bg-gradient-to-br ${game.bgColor} rounded-2xl p-6 text-center cursor-pointer`}
              onClick={() => playGame(game.id)}
            >
              <div className="text-4xl sm:text-5xl mb-4">{game.emoji}</div>
              <h3 className="text-xl sm:text-2xl font-bold text-white mb-2 comic-font">{game.title}</h3>
              <p className="cream-text font-bold comic-font text-sm sm:text-base">{game.description}</p>
              <div className="text-lg sm:text-xl font-bold text-yellow-300 mt-2 comic-font">
                {getScoreDisplay(game)}
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* Game Modal */}
        {isGameModalOpen && currentGame && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="bg-white/90 rounded-2xl p-6 sm:p-8 max-w-md w-full text-center relative"
            >
              <Button
                onClick={closeGame}
                className="absolute top-4 right-4 p-2 bg-gray-200 hover:bg-gray-300 rounded-full"
                size="sm"
              >
                <X className="w-4 h-4" />
              </Button>
              
              <div 
                className="text-black font-bold comic-font text-lg leading-relaxed"
                dangerouslySetInnerHTML={{ 
                  __html: games.find(g => g.id === currentGame)?.content || '' 
                }}
              />
              
              <Button 
                onClick={closeGame}
                className="mt-6 hot-pink-bg hover:bg-pink-600 text-white font-bold py-2 px-6 rounded-full comic-font"
              >
                Close
              </Button>
            </motion.div>
          </motion.div>
        )}
      </div>
    </section>
  );
}
