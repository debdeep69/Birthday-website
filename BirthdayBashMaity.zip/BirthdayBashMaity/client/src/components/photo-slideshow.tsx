import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

// Import the uploaded photos
import photo1 from "@assets/WhatsApp Image 2025-05-29 at 20.53.27_e6020e6a.jpg";
import photo2 from "@assets/WhatsApp Image 2025-05-29 at 21.08.14_4e292020.jpg";
import photo3 from "@assets/WhatsApp Image 2025-05-29 at 21.08.20_ff0b6a2b.jpg";
import photo4 from "@assets/WhatsApp Image 2025-05-29 at 21.08.15_98e99427.jpg";
import photo5 from "@assets/WhatsApp Image 2025-05-29 at 21.08.20_73be5729.jpg";
import photo6 from "@assets/WhatsApp Image 2025-05-29 at 21.08.12_08c46310.jpg";

export default function PhotoSlideshow() {
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);

  const photos = [
    { src: photo1, alt: "Maity with beautiful smile and green top" },
    { src: photo2, alt: "Maity with glasses and lovely smile" },
    { src: photo3, alt: "Maity in traditional pink saree" },
    { src: photo4, alt: "Maity as a cute little girl" },
    { src: photo5, alt: "Maity in traditional attire with flowers" },
    { src: photo6, alt: "Maity with friend celebrating Holi" },
    // Adding some celebratory stock photos to complete the set
    { src: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", alt: "Birthday celebration with friends" },
    { src: "https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", alt: "Beautiful birthday cake" },
    { src: "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", alt: "Colorful party decorations" },
    { src: "https://images.unsplash.com/photo-1519671482749-fd09be7ccebf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", alt: "Friends having fun at party" }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentPhotoIndex((prev) => (prev + 1) % photos.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [photos.length]);

  const nextPhoto = () => {
    setCurrentPhotoIndex((prev) => (prev + 1) % photos.length);
  };

  const prevPhoto = () => {
    setCurrentPhotoIndex((prev) => prev === 0 ? photos.length - 1 : prev - 1);
  };

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-3xl sm:text-4xl font-bold text-center text-white mb-12 comic-font"
        >
          📸 Memory Lane 📸
        </motion.h2>
        
        <div className="max-w-4xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="relative bg-white/20 backdrop-blur-md rounded-2xl p-6 sm:p-8"
          >
            <div className="relative h-64 sm:h-96 overflow-hidden rounded-xl">
              <AnimatePresence mode="wait">
                <motion.img
                  key={currentPhotoIndex}
                  src={photos[currentPhotoIndex].src}
                  alt={photos[currentPhotoIndex].alt}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ duration: 0.5 }}
                  className="absolute inset-0 w-full h-full object-cover rounded-xl"
                />
              </AnimatePresence>
            </div>
            
            <div className="flex justify-center mt-6 space-x-4">
              <Button 
                onClick={prevPhoto}
                className="viridian-bg hover:viridian-dark-bg text-white font-bold py-2 px-4 sm:px-6 rounded-full comic-font"
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Previous
              </Button>
              <Button 
                onClick={nextPhoto}
                className="hot-pink-bg hover:bg-pink-600 text-white font-bold py-2 px-4 sm:px-6 rounded-full comic-font"
              >
                Next
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
            
            <div className="flex justify-center mt-4 space-x-2">
              {photos.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentPhotoIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentPhotoIndex ? 'bg-yellow-300' : 'bg-white/50'
                  }`}
                />
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
