import { useState } from "react";
import { motion } from "framer-motion";

export default function CakeSection() {
  const [candlesBlown, setCandlesBlown] = useState(0);
  const [blownCandles, setBlownCandles] = useState<boolean[]>(new Array(5).fill(false));

  const blowCandle = (candleIndex: number) => {
    if (!blownCandles[candleIndex]) {
      const newBlownCandles = [...blownCandles];
      newBlownCandles[candleIndex] = true;
      setBlownCandles(newBlownCandles);
      setCandlesBlown(prev => prev + 1);

      // Create special confetti when all candles are blown
      if (candlesBlown + 1 === 5) {
        createSpecialConfetti();
      }
    }
  };

  const createSpecialConfetti = () => {
    const confettiContainer = document.getElementById('special-confetti');
    if (!confettiContainer) return;

    for (let i = 0; i < 50; i++) {
      setTimeout(() => {
        const confetti = document.createElement('div');
        confetti.className = 'confetti text-2xl sm:text-3xl';
        confetti.textContent = '🎊';
        confetti.style.left = Math.random() * 100 + 'vw';
        confetti.style.animationDuration = '2s';
        confettiContainer.appendChild(confetti);
        
        setTimeout(() => confetti.remove(), 2000);
      }, i * 50);
    }
  };

  const getMessage = () => {
    if (candlesBlown === 5) {
      return '🎉 All candles blown! Your wish will come true! 🎉';
    } else if (candlesBlown > 0) {
      return `${candlesBlown}/5 candles blown! Keep going! 🕯️`;
    }
    return '';
  };

  return (
    <section className="py-16 bg-white/10 backdrop-blur-md">
      <div id="special-confetti" className="fixed inset-0 pointer-events-none z-20" />
      
      <div className="container mx-auto px-4 text-center">
        <motion.h2 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-3xl sm:text-4xl font-bold text-white mb-8 comic-font"
        >
          🎂 Make a Wish & Blow the Candles! 🎂
        </motion.h2>
        
        <div className="max-w-2xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <img 
              src="https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
              alt="Beautiful birthday cake" 
              className="w-full rounded-2xl shadow-2xl"
            />
            
            <div className="absolute top-4 sm:top-8 left-1/2 transform -translate-x-1/2 flex space-x-2 sm:space-x-4">
              {blownCandles.map((isBlown, index) => (
                <motion.div 
                  key={index}
                  className={`candle ${isBlown ? 'blown' : ''}`}
                  onClick={() => blowCandle(index)}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <div className={`w-1 sm:w-2 h-8 sm:h-12 rounded-t-full ${
                    ['bg-yellow-300', 'bg-pink-300', 'bg-blue-300', 'bg-green-300', 'bg-purple-300'][index]
                  }`}></div>
                  {!isBlown && (
                    <div className="flame w-2 sm:w-3 h-3 sm:h-4 bg-orange-400 rounded-full -mt-1 ml-0.5"></div>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          <p className="text-lg sm:text-xl font-bold cream-text mt-8 mb-4 comic-font">
            Click on each candle to blow it out! 🕯️
          </p>
          
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-xl sm:text-2xl font-bold text-yellow-300 min-h-[2rem] comic-font"
          >
            {getMessage()}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
