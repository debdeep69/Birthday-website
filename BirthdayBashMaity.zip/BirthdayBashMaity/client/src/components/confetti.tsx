import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Confetti() {
  useEffect(() => {
    const createConfetti = () => {
      const confettiContainer = document.getElementById('confetti-container');
      if (!confettiContainer) return;

      const confettiColors = ['🎊', '✨', '🌟', '💫', '🎉'];
      
      const addConfetti = () => {
        const confetti = document.createElement('div');
        confetti.className = 'confetti text-xl sm:text-2xl';
        confetti.textContent = confettiColors[Math.floor(Math.random() * confettiColors.length)];
        confetti.style.left = Math.random() * 100 + 'vw';
        confetti.style.animationDuration = (Math.random() * 2 + 1) + 's';
        confettiContainer.appendChild(confetti);
        
        setTimeout(() => confetti.remove(), 3000);
      };

      const interval = setInterval(addConfetti, 200);
      return () => clearInterval(interval);
    };

    const cleanup = createConfetti();
    return cleanup;
  }, []);

  return <div id="confetti-container" className="fixed inset-0 pointer-events-none z-20" />;
}
