import { useEffect } from "react";

export default function FallingAnimations() {
  useEffect(() => {
    // Falling flowers animation
    const createFallingFlowers = () => {
      const flowersContainer = document.getElementById('falling-flowers');
      if (!flowersContainer) return;

      const flowers = ['🌻', '🌸', '🌺', '🌼', '💐', '🌷', '🌹'];
      
      const addFlower = () => {
        const flower = document.createElement('div');
        flower.className = 'falling-flower text-2xl sm:text-4xl';
        flower.textContent = flowers[Math.floor(Math.random() * flowers.length)];
        flower.style.left = Math.random() * 100 + 'vw';
        flower.style.animationDuration = (Math.random() * 3 + 2) + 's';
        flowersContainer.appendChild(flower);
        
        setTimeout(() => flower.remove(), 5000);
      };

      const interval = setInterval(addFlower, 500);
      return () => clearInterval(interval);
    };

    // Flying balloons animation
    const createFlyingBalloons = () => {
      const balloonsContainer = document.getElementById('flying-balloons');
      if (!balloonsContainer) return;

      const balloons = ['🎈', '🎎', '🎀', '🎪', '🎭'];
      
      const addBalloon = () => {
        const balloon = document.createElement('div');
        balloon.className = 'floating-balloon text-2xl sm:text-3xl';
        balloon.textContent = balloons[Math.floor(Math.random() * balloons.length)];
        balloon.style.left = Math.random() * 100 + 'vw';
        balloon.style.animationDuration = (Math.random() * 5 + 5) + 's';
        balloonsContainer.appendChild(balloon);
        
        setTimeout(() => balloon.remove(), 10000);
      };

      const interval = setInterval(addBalloon, 1000);
      return () => clearInterval(interval);
    };

    const flowersCleanup = createFallingFlowers();
    const balloonsCleanup = createFlyingBalloons();

    return () => {
      flowersCleanup?.();
      balloonsCleanup?.();
    };
  }, []);

  return (
    <>
      <div id="falling-flowers" className="fixed inset-0 pointer-events-none z-10" />
      <div id="flying-balloons" className="fixed inset-0 pointer-events-none z-5" />
    </>
  );
}
