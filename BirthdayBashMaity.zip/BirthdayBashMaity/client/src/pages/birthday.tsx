import { useEffect } from "react";
import { motion } from "framer-motion";
import Confetti from "@/components/confetti";
import FallingAnimations from "@/components/falling-animations";
import PhotoSlideshow from "@/components/photo-slideshow";
import CakeSection from "@/components/cake-section";
import GamesSection from "@/components/games-section";
import MusicPlayer from "@/components/music-player";

export default function BirthdayPage() {
  useEffect(() => {
    document.title = "Happy 18th Birthday Maity! 🎉";
  }, []);

  return (
    <div className="min-h-screen overflow-x-hidden bg-gradient-to-br from-viridian-600 via-pink-500 to-viridian-800">
      {/* Background Animations */}
      <FallingAnimations />
      <Confetti />
      
      {/* Header Section */}
      <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <motion.div 
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
          className="text-center z-20 bg-white/20 backdrop-blur-md rounded-3xl p-8 mx-4 border border-white/30"
        >
          <motion.h1 
            initial={{ y: -50 }}
            animate={{ y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="text-4xl sm:text-6xl md:text-8xl font-bold text-white mb-6 drop-shadow-lg comic-font"
          >
            🎉 HAPPY 18TH BIRTHDAY 🎉
          </motion.h1>
          
          <motion.h2 
            initial={{ y: 50 }}
            animate={{ y: 0 }}
            transition={{ delay: 0.7, duration: 0.8 }}
            className="text-3xl sm:text-4xl md:text-6xl font-bold text-yellow-300 mb-8 drop-shadow-lg comic-font"
          >
            MAITY!
          </motion.h2>
          
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1 }}
            className="flex justify-center space-x-2 sm:space-x-4 mb-8"
          >
            {['text-red-500', 'text-orange-500', 'text-yellow-500', 'text-green-500', 'text-blue-500', 'text-indigo-500', 'text-purple-500'].map((color, index) => (
              <div key={index} className={`glowing-bulb ${color} text-2xl sm:text-4xl`}>💡</div>
            ))}
          </motion.div>
          
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="text-xl sm:text-2xl md:text-3xl font-bold cream-text comic-font"
          >
            From: Argho 💖
          </motion.p>
        </motion.div>
      </section>

      {/* Music Player Section */}
      <MusicPlayer />

      {/* Photo Slideshow Section */}
      <PhotoSlideshow />

      {/* Cake Cutting Section */}
      <CakeSection />

      {/* Maity's Favorites Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <motion.h2 
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-3xl sm:text-4xl font-bold text-center text-white mb-12 comic-font"
          >
            💖 Things Maity Loves 💖
          </motion.h2>
          
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto">
            {[
              { emoji: '🌻', title: 'Sunflowers', desc: 'Bright and cheerful, just like Maity\'s personality!', color: 'text-yellow-300' },
              { emoji: '🎵', title: 'Music', desc: 'Dancing to the rhythm of life!', color: 'hot-pink-text' },
              { emoji: '📚', title: 'Reading', desc: 'Getting lost in amazing stories!', color: 'viridian-text' },
              { emoji: '🍰', title: 'Baking', desc: 'Creating sweet memories!', color: 'text-orange-300' },
              { emoji: '🎨', title: 'Art', desc: 'Painting the world with creativity!', color: 'text-purple-300' },
              { emoji: '🌸', title: 'Flowers', desc: 'Spreading beauty everywhere!', color: 'text-pink-300' }
            ].map((item, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="bg-white/20 backdrop-blur-md rounded-2xl p-6 text-center hover:transform hover:scale-105 transition-all duration-300"
              >
                <div className="text-4xl sm:text-6xl mb-4">{item.emoji}</div>
                <h3 className={`text-xl sm:text-2xl font-bold ${item.color} mb-4 comic-font`}>{item.title}</h3>
                <p className="cream-text font-bold comic-font text-sm sm:text-base">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Games Section */}
      <GamesSection />

      {/* Special Message Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto bg-white/20 backdrop-blur-md rounded-3xl p-8 sm:p-12"
          >
            <div className="pulse-heart text-6xl sm:text-8xl mb-8">💝</div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-8 comic-font">A Special Message for Maity</h2>
            
            <div className="bg-gradient-to-r from-pink-500 to-viridian-600 rounded-2xl p-6 sm:p-8 mb-8">
              <p className="text-lg sm:text-2xl md:text-3xl font-bold text-white leading-relaxed comic-font">
                "BHALO THAKIS FORGIVE ME IF I DESERVE AM SORRY → I LOVE U MAITY 😭🤍🧿🙏🏼"
              </p>
            </div>
            
            <p className="text-lg sm:text-xl font-bold cream-text mb-6 comic-font">
              With all my love and best wishes for your 18th birthday! 
            </p>
            <p className="text-xl sm:text-2xl font-bold text-yellow-300 comic-font">
              - Argho 💖
            </p>
            
            <div className="mt-8 flex justify-center space-x-4">
              {['🎉', '🎂', '🎈', '🌸', '💖'].map((emoji, index) => (
                <motion.div 
                  key={index}
                  animate={{ y: [0, -10, 0] }}
                  transition={{ 
                    duration: 1, 
                    repeat: Infinity, 
                    delay: index * 0.1 
                  }}
                  className="text-3xl sm:text-4xl"
                >
                  {emoji}
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-black/30 backdrop-blur-md text-center">
        <p className="text-lg sm:text-xl font-bold cream-text comic-font">
          Happy 18th Birthday Maity! 🎊 May all your dreams come true! ✨
        </p>
      </footer>
    </div>
  );
}
